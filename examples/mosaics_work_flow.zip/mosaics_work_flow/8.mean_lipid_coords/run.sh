#!/bin/bash
  
#SBATCH --job-name=mlc
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../1.traj_prep/ref.gro"
trajectory="../1.traj_prep/traj_fit.xtc"

#mean_lipid_coords
mpirun -n 56 $mos/mean_lipid_coords_mpi -traj $trajectory -ref $reference -param popc_no_h.gro -mlc upper_mlc.pdb -m1 C21 -m2 C31 -APS 0.16 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm 
mpirun -n 56 $mos/mean_lipid_coords_mpi -traj $trajectory -ref $reference -param popc_no_h.gro -mlc lower_mlc.pdb -m1 C21 -m2 C31 -APS 0.16 -r 0.26 -cutoff 0.4 -leaf 2 -lf_pdb leaflets.pdb -lf_prm pg.prm  

#mean protein coords
mpirun -n 56 $mos/mean_protein_coords_mpi -traj $trajectory -ref $reference -mpc mean_prot.pdb

