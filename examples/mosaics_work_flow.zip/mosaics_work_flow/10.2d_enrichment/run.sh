#!/bin/bash
  
#SBATCH --job-name=enrich
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../1.traj_prep/ref.gro"
trajectory="../1.traj_prep/traj_fit.xtc"

#2d enrichment
mpirun -n 56 $mos/2d_enrichment_mpi -traj $trajectory -ref $reference -crd_1 popg.crd -crd_2 popc.crd -enrich upper_pg_enrich.dat -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm 
mpirun -n 56 $mos/2d_enrichment_mpi -traj $trajectory -ref $reference -crd_1 popg.crd -crd_2 popc.crd -enrich lower_pg_enrich.dat -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 2 -lf_pdb leaflets.pdb -lf_prm pg.prm  

#make plots
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [-100:100]   upper_pg_enrich.dat upper_pg_enrich.png
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [-100:100]   lower_pg_enrich.dat lower_pg_enrich.png

