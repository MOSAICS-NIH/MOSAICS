#!/bin/bash
  
#SBATCH --job-name=prep
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#step 1: examine trajectory
mpirun -n 56 $mos/mosat_mpi -traj traj.xtc -ref ref.gro -o traj_skip_10.pdb -stride 10 

#step 2: generate a bonds list. 
mpirun -n 1 $mos/bonds_generator -d ref.psf -o bonds.crd -con 0

#step 3: check that the bonds list identifies molecules properly
mpirun -n 1 $mos/traj_prep_mpi -traj traj.xtc -ref ref.gro -crd check_bonds.crd -o bonds_check.pdb -stride 1 -test 1 -stop 10 -e 0

#step 4: make an index for tm alpha carbons
mpirun -n 1 $mos/atom_select_mpi -traj ref.gro -ref ref.gro -sel tm_ca.sel -leaf 0

#step 5: make an index for each protomer 
mpirun -n 1 $mos/atom_select_mpi -traj ref.gro -ref ref.gro -sel prot_1.sel -leaf 0
mpirun -n 1 $mos/atom_select_mpi -traj ref.gro -ref ref.gro -sel prot_2.sel -leaf 0
mpirun -n 1 $mos/atom_select_mpi -traj ref.gro -ref ref.gro -sel prot_3.sel -leaf 0
mpirun -n 1 $mos/atom_select_mpi -traj ref.gro -ref ref.gro -sel prot_4.sel -leaf 0

#step 6: orient the protein and wrap the molecular system
mpirun -n 56 $mos/traj_prep_mpi -traj traj.xtc -ref ref.gro -crd recipe.crd -o traj_fit.xtc 
 
#step 7: check the trajectory
mpirun -n 56 $mos/mosat_mpi -traj traj_fit.xtc -ref ref.gro -o traj_fit.pdb -stride 10  

#############################################################################################################
#                                                                                                           #
# make a trajectory for area per lipid calculations (no rotations)                                          #
#                                                                                                           #
#############################################################################################################

#step 8: make a trajectory with protein centered but do not perform rotations
mpirun -n 56 $mos/traj_prep_mpi -traj traj.xtc -ref ref.gro -crd recipe_no_lsq.crd -o traj_no_lsq.xtc

#############################################################################################################
#                                                                                                           #
# make an unwrapped trajectory for measuring the diffusion coefficient                                      #
#                                                                                                           #
#############################################################################################################

#step 9: unwrap molecular system
mpirun -n 1 $mos/pbc_xy_mpi -traj traj.xtc  -ref ref.gro -o traj_no_jump.xtc -cutoff 0.5

