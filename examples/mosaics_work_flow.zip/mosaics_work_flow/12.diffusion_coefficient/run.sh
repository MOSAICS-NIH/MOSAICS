#!/bin/bash
  
#SBATCH --job-name=msd
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../1.traj_prep/ref.gro"
trajectory="../1.traj_prep/traj_no_jump.xtc"

#lipid msd
mpirun -n 56 $mos/lipid_msd_mpi -traj $trajectory -ref $reference -crd popc.crd -msd msd_popc.dat -dt 1200.0 -lf_prm pg.prm 

#make plots
$gnu/gnuplot -c msd.gnu [:] [:] msd_popc.dat msd_popc.png 265

