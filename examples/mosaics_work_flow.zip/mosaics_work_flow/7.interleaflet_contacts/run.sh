#!/bin/bash
  
#SBATCH --job-name=ilc
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../1.traj_prep/ref.gro"
trajectory="../1.traj_prep/traj_fit.xtc"

#set screen distance
screen="5.0"

#check the screening distance is not too small
mpirun -n 56 $mos/inter_leaflet_contacts_mpi -traj $trajectory -ref $reference -crd_1 pcpg_t.crd -crd_2 pcpg_op.crd -lfc w_screen.dat  -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm -cdist 0.35 -screen $screen -stride 100 
mpirun -n 56 $mos/inter_leaflet_contacts_mpi -traj $trajectory -ref $reference -crd_1 pcpg_t.crd -crd_2 pcpg_op.crd -lfc wo_screen.dat -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm -cdist 0.35 -stride 100
cmp w_screen.dat wo_screen.dat || echo "Files are different, increase -screen distance!"

#interleaflet contacts
mpirun -n 56 $mos/inter_leaflet_contacts_mpi -traj $trajectory -ref $reference -crd_1 pcpg_t.crd -crd_2 pcpg_op.crd -lfc upper_ilc.dat -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm -cdist 0.35 -screen $screen
mpirun -n 56 $mos/inter_leaflet_contacts_mpi -traj $trajectory -ref $reference -crd_1 pcpg_t.crd -crd_2 pcpg_op.crd -lfc lower_ilc.dat -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 2 -lf_pdb leaflets.pdb -lf_prm pg.prm -cdist 0.35 -screen $screen

#make plots
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [:]   upper_ilc.dat upper_ilc.png
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [:]   lower_ilc.dat lower_ilc.png

