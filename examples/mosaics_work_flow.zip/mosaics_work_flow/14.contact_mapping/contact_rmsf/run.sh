#!/bin/bash
  
#SBATCH --job-name=crmsf
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../../1.traj_prep/ref.gro"
trajectory="../../1.traj_prep/traj_fit.xtc"

#check which lipid type is at the binding site
mpirun -n 1 $mos/binding_list_mpi -d ../../6.2d_kinetics/be/upper/upper.be -mode 0 -t 0 -x 125 -y 80

#contact rmsf
mpirun -n 56 $mos/contact_rmsf_mpi -traj $trajectory -ref $reference -crmsf binding_site.pdb -resi -1 -cdist 0.6 -sel prot.sel -be ../../6.2d_kinetics/be/upper/upper.be -type POPG -x 125 -y 80

#copy data to folder for making figure
cp binding_site_rmsf.pdb ../contact_mapping/contact_rmsf/

