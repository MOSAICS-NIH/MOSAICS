#!/bin/bash
  
#SBATCH --job-name=ckin
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../../1.traj_prep/ref.gro"
trajectory="../../1.traj_prep/traj_fit.xtc"

#contact kinetics
mpirun -n 56 $mos/contact_kinetics_mpi -traj $trajectory -ref $reference -ck binding_site.dat -resi -1 -cdist 0.35 -range 0 -dump 1 -dt 1200.0 -bin 1000.0 -min -0.03333 -max 0.3 -be ../../6.2d_kinetics/be/upper/upper.be -type POPG -x 125 -y 80

#copy data to folder for making figure
cp *.pml ../contact_mapping/contact_kinetics/

