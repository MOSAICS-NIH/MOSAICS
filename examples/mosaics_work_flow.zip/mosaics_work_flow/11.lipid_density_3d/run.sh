#!/bin/bash
  
#SBATCH --job-name=ld_3d
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../1.traj_prep/ref.gro"
trajectory="../1.traj_prep/traj_fit.xtc"

#check the stamping radius on a trajectory frame
mpirun -n 1  $mos/lipid_density_3d_mpi -traj $trajectory -ref $reference -crd pcpg.crd -rho test.dx  -APS 0.001 -r 0.05 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm -e 0 -o frame_0.pdb

#lipid density 3d
mpirun -n 56 $mos/lipid_density_3d_mpi -traj $trajectory -ref $reference -crd pcpg.crd -rho chains.dx -APS 0.001 -r 0.05 -leaf 0 -lf_pdb leaflets.pdb -lf_prm pg.prm -dist 1.0


