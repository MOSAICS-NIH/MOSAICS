#!/bin/bash
  
#SBATCH --job-name=lhb
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../../1.traj_prep/ref.gro"
trajectory="../../1.traj_prep/traj_fit.xtc"

#check some h-bonds identified in first trajectory frame
mpirun -n 1  $mos/lipid_h_bonds_mpi -traj $trajectory -ref $reference -crd pcpg.crd -lip_a lip_a.crd -lip_d lip_d.crd -prot_a prot_a.crd -prot_d prot_d.crd -bond ../../1.traj_prep/bonds.crd -lphb test.dat     -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm -test 1 -o frame_0.pdb -e 0 

#lipid h-bonds
mpirun -n 56 $mos/lipid_h_bonds_mpi -traj $trajectory -ref $reference -crd pcpg.crd -lip_a lip_a.crd -lip_d lip_d.crd -prot_a prot_a.crd -prot_d prot_d.crd -bond ../../1.traj_prep/bonds.crd -lphb upper_hb.dat -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm 
mpirun -n 56 $mos/lipid_h_bonds_mpi -traj $trajectory -ref $reference -crd pcpg.crd -lip_a lip_a.crd -lip_d lip_d.crd -prot_a prot_a.crd -prot_d prot_d.crd -bond ../../1.traj_prep/bonds.crd -lphb lower_hb.dat -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 2 -lf_pdb leaflets.pdb -lf_prm pg.prm 

#subtract salt-bridges
$mos/delta_plot -d1 ../salt_bridges/upper_sb.dat -d2 upper_hb.dat -o upper_hb_minus_sb.dat -odf 0 
$mos/delta_plot -d1 ../salt_bridges/lower_sb.dat -d2 lower_hb.dat -o lower_hb_minus_sb.dat -odf 0 

#make plots
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [0:4]   upper_hb_minus_sb.dat upper_hb_minus_sb.png
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [0:4]   lower_hb_minus_sb.dat lower_hb_minus_sb.png

