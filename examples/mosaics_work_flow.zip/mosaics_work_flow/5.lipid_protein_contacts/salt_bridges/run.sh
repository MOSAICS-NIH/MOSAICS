#!/bin/bash
  
#SBATCH --job-name=lsb
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../../1.traj_prep/ref.gro"
trajectory="../../1.traj_prep/traj_fit.xtc"

#check some salt-bridges (h-bonds) identified in first trajectory frame
mpirun -n 1  $mos/lipid_h_bonds_mpi -traj $trajectory -ref $reference -crd pcpg.crd -lip_a lip_a.crd -lip_d lip_d.crd -prot_a prot_a.crd -prot_d prot_d.crd -bond ../../1.traj_prep/bonds.crd -lphb test.dat     -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm -test 1 -o frame_0.pdb -e 0 

#count salt bridges using lipid h-bonds
mpirun -n 56 $mos/lipid_h_bonds_mpi -traj $trajectory -ref $reference -crd pcpg.crd -lip_a lip_a.crd -lip_d lip_d.crd -prot_a prot_a.crd -prot_d prot_d.crd -bond ../../1.traj_prep/bonds.crd -lphb upper_sb.dat -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm 
mpirun -n 56 $mos/lipid_h_bonds_mpi -traj $trajectory -ref $reference -crd pcpg.crd -lip_a lip_a.crd -lip_d lip_d.crd -prot_a prot_a.crd -prot_d prot_d.crd -bond ../../1.traj_prep/bonds.crd -lphb lower_sb.dat -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 2 -lf_pdb leaflets.pdb -lf_prm pg.prm 

#make plots
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [0:1.6]   upper_sb.dat upper_sb.png
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [0:1.6]   lower_sb.dat lower_sb.png

