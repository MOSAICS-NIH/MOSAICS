#!/bin/bash
  
#SBATCH --job-name=ss
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=4
#SBATCH --ntasks=112
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#solvation shells
mpirun -n 100 $mos/solvation_shells_mpi -d ../be/upper/upper.be -prot ../upper_prot_mask.dat -o shells/upper.be -odf 0 -stride 1 -dist_1 0.2 -dist_n 0.3 -n_shel 2 -n_box 2 -x 103 -y 103 -rx 110 -ry 110 -invert 0 
mpirun -n 100 $mos/solvation_shells_mpi -d ../be/lower/lower.be -prot ../lower_prot_mask.dat -o shells/lower.be -odf 0 -stride 1 -dist_1 0.2 -dist_n 0.3 -n_shel 2 -n_box 2 -x 103 -y 103 -rx 110 -ry 110 -invert 0

#measure dwell time in first shell
mpirun -n 1 $mos/binding_events_analyzer_single_mpi -d shells/upper_first_shell.be -crd pcpg.crd 
