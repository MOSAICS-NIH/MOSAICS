#!/bin/bash
  
#SBATCH --job-name=dwell_t
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#dwell time
mpirun -n 56 $mos/binding_events_analyzer_mpi -d ../be/upper/upper.be -o upper_pcpg.dat -crd pcpg.crd -rho ../be/upper/upper_rho.dat -cutoff 0.4 
mpirun -n 56 $mos/binding_events_analyzer_mpi -d ../be/lower/lower.be -o lower_pcpg.dat -crd pcpg.crd -rho ../be/lower/lower_rho.dat -cutoff 0.4

#plot data
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [10000:100000]   upper_pcpg_dwell_time.dat upper_pcpg_dwell_time.png
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [10000:100000]   lower_pcpg_dwell_time.dat lower_pcpg_dwell_time.png

