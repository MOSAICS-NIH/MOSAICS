#!/bin/bash

#SBATCH --job-name=vid
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=4
#SBATCH --ntasks=100
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=25
#SBATCH --time=24:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#binding events video
mpirun -n 100 $mos/binding_events_video_mpi -d ../be/upper/upper.be -o upper/upper.dat -stride 1 -rho ../be/upper/upper_rho.dat -cutoff 0.4 -odf 0
mpirun -n 100 $mos/binding_events_video_mpi -d ../be/lower/lower.be -o lower/lower.dat -stride 1 -rho ../be/lower/lower_rho.dat -cutoff 0.4 -odf 0

#make plots
sh get_vid_plots_upper.sh upper/upper 0 100 upper_plots/ 1  1200
sh get_vid_plots_lower.sh lower/lower 0 100 lower_plots/ 1  1200

