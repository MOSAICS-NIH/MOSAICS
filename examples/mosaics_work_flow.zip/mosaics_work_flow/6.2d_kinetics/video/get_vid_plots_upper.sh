#!/bin/bash
core_name=$1
imin=$2
imax=$3
folder=$4
stride=$5 
dt=$6

export gnu=path_to_gnu_plots

i=0
for ((i=$imin; i<$imax; i+=$stride)); do
    in_name=$core_name'_'"$i"".dat"
    out_name=$core_name'_'"$i"".png"
    time=`echo "$i*$dt*0.000001" | bc`
    $gnu/gnuplot -c heatmap_template_video_upper.gnu [0:200]   [0:200] [0:260]     $in_name   $out_name "Simulation time $time us"
    mv $out_name $folder
done



