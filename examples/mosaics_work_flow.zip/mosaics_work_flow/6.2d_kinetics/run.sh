#!/bin/bash
  
#SBATCH --job-name=2d_kinetics
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=36
#SBATCH --ntasks=1008
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../1.traj_prep/ref.gro"
trajectory="../1.traj_prep/traj_fit.xtc"

#make a protein mask
$mos/protein_mask -d ../2.membrane_thickness/upper_z_rho.dat -o upper_prot_mask.dat -cutoff 0.0 -odf 0
$mos/protein_mask -d ../2.membrane_thickness/lower_z_rho.dat -o lower_prot_mask.dat -cutoff 0.0 -odf 0

#check masks
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [:] upper_prot_mask.dat upper_prot_mask.png
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [:] lower_prot_mask.dat lower_prot_mask.png

#2d kinetics
mpirun -n 1000 $mos/2d_kinetics_mpi -traj $trajectory -ref $reference -crd pcpg.crd -k be/upper/upper.dat -APS 0.005 -r 0.26 -leaf 1 -range 2 -dt 1200.0 -v_prot 0 -clean 1 -dump 1 -mask upper_prot_mask.dat -mem 2000.0 -lf_prm pg.prm 
mpirun -n 1000 $mos/2d_kinetics_mpi -traj $trajectory -ref $reference -crd pcpg.crd -k be/lower/lower.dat -APS 0.005 -r 0.26 -leaf 2 -range 2 -dt 1200.0 -v_prot 0 -clean 1 -dump 1 -mask lower_prot_mask.dat -mem 2000.0 -lf_prm pg.prm

