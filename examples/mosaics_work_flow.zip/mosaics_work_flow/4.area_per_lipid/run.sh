#!/bin/bash

#SBATCH --job-name=apl
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../1.traj_prep/ref.gro"
trajectory="../1.traj_prep/traj_fit.xtc"
trajectory_v="../1.traj_prep/traj_no_lsq.xtc"

#apl
mpirun -n 56 $mos/apl_mpi -traj $trajectory -ref $reference -traj_v $trajectory_v -crd_1 target_lip.crd -crd_2 voro.crd -apl upper_apl.dat -c_dist 0.6 -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm
mpirun -n 56 $mos/apl_mpi -traj $trajectory -ref $reference -traj_v $trajectory_v -crd_1 target_lip.crd -crd_2 voro.crd -apl lower_apl.dat -c_dist 0.6 -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 2 -lf_pdb leaflets.pdb -lf_prm pg.prm

#make plots
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [:]   upper_apl.dat upper_apl.png
$gnu/gnuplot -c heatmap_template.gnu [0:200] [0:200] [:]   lower_apl.dat lower_apl.png

