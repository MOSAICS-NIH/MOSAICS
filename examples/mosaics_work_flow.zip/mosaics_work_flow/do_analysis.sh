#!/bin/bash

#traj prep
prep=$(sbatch -D 1.traj_prep/ run.sh)

#membrane thickness
z=$(sbatch --dependency=afterany:$prep -D 2.membrane_thickness/ run.sh)

#lipid tilt angle
theta=$(sbatch --dependency=afterany:$prep -D 3.lipid_tilt/ run.sh)

#area per lipid
apl=$(sbatch --dependency=afterany:$prep -D 4.area_per_lipid/ run.sh)

#lipid-protein contacts (plain)
cont=$(sbatch --dependency=afterany:$prep -D 5.lipid_protein_contacts/plain_contacts/ run.sh)

#lipid-protein contacts (salt-bridges)
sb=$(sbatch --dependency=afterany:$prep -D 5.lipid_protein_contacts/salt_bridges/ run.sh)

#lipid-protein contacts (h-bonds)
hb=$(sbatch --dependency=afterany:$sb -D 5.lipid_protein_contacts/h_bonds/ run.sh)
 
#2d_kinetics
kin=$(sbatch --dependency=afterany:$z -D 6.2d_kinetics/ run.sh)

#dwell time
dwell_t=$(sbatch --dependency=afterany:$kin -D 6.2d_kinetics/dwell_time/ run.sh)

#video
vid=$(sbatch --dependency=afterany:$kin -D 6.2d_kinetics/video/ run.sh)

#first shell dwell time
ss=$(sbatch --dependency=afterany:$kin -D 6.2d_kinetics/solvation_shells/ run.sh)

#interleaflet contacts
ilc=$(sbatch --dependency=afterany:$prep -D 7.interleaflet_contacts/ run.sh)

#mean lipid coords
mlc=$(sbatch --dependency=afterany:$prep -D 8.mean_lipid_coords/ run.sh)

#lipid distances
splay=$(sbatch --dependency=afterany:$prep -D 9.lipid_distances/ run.sh)

#2d enrichment
enrich=$(sbatch --dependency=afterany:$prep -D 10.2d_enrichment/ run.sh)

#lipid density 3d
rho=$(sbatch --dependency=afterany:$prep -D 11.lipid_density_3d/ run.sh)

#diffusion coefficient
dif=$(sbatch --dependency=afterany:$prep -D 12.diffusion_coefficient/ run.sh)

#lipid mixing
mix=$(sbatch --dependency=afterany:$prep -D 13.lipid_mixing/ run.sh)

#contact rmsf
crmsf=$(sbatch --dependency=afterany:$kin -D 14.contact_mapping/contact_rmsf/ run.sh)

#contact kinetics
ckin=$(sbatch --dependency=afterany:$kin -D 14.contact_mapping/contact_kinetics/ run.sh)

