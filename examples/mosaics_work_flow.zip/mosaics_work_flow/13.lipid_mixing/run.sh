#!/bin/bash
  
#SBATCH --job-name=lmix
#SBATCH --partition=multinode
#SBATCH --constraint=[x2680|x2695]
#SBATCH --nodes=2
#SBATCH --ntasks=56
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=28
#SBATCH --time=72:00:00
#SBATCH --mem-per-cpu=4g
#SBATCH --no-requeue
#SBATCH --exclusive

#load mosaics
export mos=path_to_mosaics
export gnu=path_to_gnu_plots

#set system variables
reference="../1.traj_prep/ref.gro"
trajectory="../1.traj_prep/traj_fit.xtc"

#lipid mixing
mpirun -n 56 $mos/lipid_mixing_mpi -traj $trajectory -ref $reference -crd_1 pcpg_t.crd -crd_2 pcpg_v.crd -mix upper_mixing.dat -mix_s 10 -dt 1200.0 -m1 C21 -m2 C31 -range 2 -freq 0.5 -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 1 -lf_pdb leaflets.pdb -lf_prm pg.prm 
mpirun -n 56 $mos/lipid_mixing_mpi -traj $trajectory -ref $reference -crd_1 pcpg_t.crd -crd_2 pcpg_v.crd -mix lower_mixing.dat -mix_s 10 -dt 1200.0 -m1 C21 -m2 C31 -range 2 -freq 0.5 -APS 0.005 -r 0.26 -cutoff 0.4 -leaf 2 -lf_pdb leaflets.pdb -lf_prm pg.prm  
#average over upper and lower leaflet
$mos/data_averager -crd files.crd -o avg_mixing.dat

#make plots
$gnu/gnuplot -c line_graph.gnu [0:100] [:]   avg_mixing.dat       avg_mixing.png       "title"


